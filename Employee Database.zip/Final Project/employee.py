# !/usr/bin/env python3
# Mason Andersen
# 12-19-2021
# This module defines the Employee class.
#


## A person with first and last name, middle initial, date of birth
#
class Employee :

    ## Constructs an employee with default attributes, or the user can enter some
    #
    def __init__(self, ID = "", first = "", last = "", job = "", dept = ""):
        self._firstName = first
        self._lastName = last
        self._name = first + " " + last
        self._IDnum = ID
        self._dept = dept
        self._job = job

    ## Gets the ID number of an employee
    #  @return the ID number of the employee
    #
    @property
    def IDnumber(self):
        return self._IDnum

    ## Sets the ID number of an employee
    #  @param num the ID number to be given
    #
    @IDnumber.setter
    def IDnumber(self, num):
        self._IDnum = num

    ## Gets the first name of an employee
    #  @return the first name of the employee
    #
    @property
    def firstName(self):
        self._setFullName()
        return self._firstName

    ## Sets the first name of an employee
    #  @param name the name to be given
    #
    @firstName.setter
    def firstName(self, name):
        self._setFullName()
        self._firstName = name

    
    ## Gets the last name of an employee
    #  @return the last name of an employee
    #
    @property
    def lastName(self):
        return self._lastName

    ## Sets the last name of an employee
    #  @param last the name to be given
    #
    @lastName.setter
    def lastName(self, last):
        self._lastName = last

    ## Gets the job title of an employee
    #  @return the job title of the employee
    #
    @property
    def job(self):
        return self._job

    ## Sets the job title of an employee
    #  @param job the job title to be given
    #
    @job.setter
    def job(self, job):
        self._job = job

    ## Gets the department of an employee
    #  @return the department of the employee
    #
    @property
    def dept(self):
        return self._dept

    ## Sets the department of an employee
    #  @param dept the department to be given
    #
    @dept.setter
    def dept(self, dept):
        self._dept = dept
    
    ## Calculates the full name of an employee given first and last names
    #
    def _setFullName(self):
        self._name =(self._firstName + " " + self._lastName)

        
        
    ## Gets the full name of an employee
    #  @return full name of the employee
    #
    @property
    def name(self):
        self._setFullName()
        return self._name

    ## Sets the full name of an employee
    #  @param name the name to be given
    #
    @name.setter
    def name(self, name):
        names = name.split()
        self._firstName = names[0]
        self._lastName = names[1] 
        self._name = name
        
    
    ## returns a string representing the employee object
    #
    def __repr__(self):
        self._setFullName()
        return ("Employee #" + self._IDnum + "\nName: " + self._name + " \ndept: " +
                self._dept + " \njob title: " + self._job )
