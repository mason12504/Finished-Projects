# !/usr/bin/env python3
# Mason Andersen
# 12-19-2021
# This module creates the employee database.
#

# import employee class and re for regex 
from employee import Employee
import re

## runs other functions to create the employee database system
#
def main():

    # open file, create dictionary
    inFile = open("EmployeeStorage.txt", "r")
    mainDictionary = makeDictionary(inFile)
    # initialize user selection
    userInput = "0"
    

    # loop through an input menu until the user enters the quit value
    while userInput != "6":
        
        # display menu and get input
        showMenu()
        userInput = input("Entry: ")

        # input of 1 is employee lookup
        if userInput == "1":

            # take the ID number as input, find and print the employee with that ID number
            selection = input("Enter the employee ID number: ")
            lookup(selection, mainDictionary)
            
        # input of 2 is add employee
        elif userInput == "2":
            addEmployee(mainDictionary)
            
        # input of 3 is change employee
        elif userInput == "3":
            changeEmployee(mainDictionary)
            
        # input of 4 is delete employee
        elif userInput == "4":
            selection = input("Enter the ID of the employee to delete: ")
            deleteEmployee(selection, mainDictionary)
            
        # input of 5 is list all employees
        elif userInput == "5":
            print("\nAll Employees currently in the system:")
            
            # print out a representation of each employee
            for ID in mainDictionary:
                showEmployee(mainDictionary, ID)
        else:
            if userInput != "6":
                print("\nEnter a number between 1 and 6\n")
    
    # now that the file has been read, close and
    # open again to write changes that have happened
    inFile.close()
    inFile = open("EmployeeStorage.txt", "w")
    
    # update file data on exit
    updateFile(inFile, mainDictionary)
    
    
    # let the user know they quit the program
    print("\nGoodbye")
        

## creates a dictionary from a file input
#  @param file the file input
#  @return employeeDict the complete dictionary
#
def makeDictionary(file):
    
    # create an empty dictionary
    employeeDict = {}

    # loop through the file line by line
    for line in file:
        
        # remove the endline character
        line = line.strip('\n')
        
        # create a list of values which are the employee attributes
        employeeText = line.split(",")

        # create class object from list of attributes
        employee = Employee()
        employee.IDnumber = employeeText[0]
        employee.firstName = employeeText[1]
        employee.lastName = employeeText[2]
        employee.job = employeeText[4]
        employee.dept = employeeText[3]
        
        # add employee to dictionary
        employeeDict[employee.IDnumber] = employee
    
    return employeeDict


## produces a selection menu for the user
#  
def showMenu():

    # define string before printing to have format correct
    string = ("""Select one of the following choices:\n
    1. Look up employee\n
    2. Add new employee\n
    3. Change an existing employee\n
    4. Delete an employee \n
    5. List all employees\n
    6. Save changes and quit the program\n""")
    print(string)


## looks up an employee in the dictionary given the dictionary of storage, and the ID number
#  @param IDnum the employee's ID number
#  @param dictionary the dictionary in which the employee is stored
#
def lookup(ID, dictionary):
    
    # if the employee exists, print the employee
    if ID in dictionary:
        showEmployee(dictionary, ID)
        
    # otherwise let the user know the employee does not exist
    else:
        print("\nEmployee not found.\n")


## adds an employee to the dictionary
#  @param dictionary the dictionary to which the employee is added
#
def addEmployee(dictionary):

    # get the employee's ID number
    addID = input("Enter the ID number of the new employee: ")
    
    # if the user inputs an invalid ID number, ask them again or exit
    if verifyID(addID) == False:
        while (verifyID(addID) == False) and addID != "":
            print("\nThe employee ID number must be all digits and nothing else\n")
            addID = input("Enter a valid ID number, or press Enter to quit: ")
            verifyID(addID)
            
    # if the ID entered is already in the dictionary, let the user know
    if addID in dictionary:
        print("\nEmployee " + addID + " is already in the system.\n")
        return 0

    # formatting for if the user exits
    if addID == "":
        print("\n")
        return 0
            
    # get user input for all the attributes    
    addFname = input("Enter the first name of the employee: ")
    addLname = input("Enter the last name of the employee: ")
    addJob = input("Enter the employee's job title: ")
    addDept = input("Enter the employee's department: ")

    # create employe object with the entered values
    employee = Employee(addID, addFname, addLname, addJob, addDept)
    
    # add the employee to the dictionary
    dictionary[addID] = employee

    # let the user know the employee has been added
    print("\nAdded employee", addID + ":", addFname, addLname, "to the dictionary.\n")


## changes an employee in a given dictionary
#  @param dictionary the dictionary the employee is in
#
def changeEmployee(dictionary):

    # get user input
    ID = input("Enter the ID number of the employee to be changed: ")
    
    # if the user inputs a valid ID number, let them change attributes
    if ID in dictionary:
        
        # show another menu for changing the existing employee
        # assign newData to a list which contains new employee data
        newData = changeEmpMenu(ID)

        # get employee object from dictionary
        employee = dictionary[ID]

        # assign the new attributes to the employee
        # if empty spaces are in the list, attributes are left as is
        if newData[0] != "":
            employee.firstName = newData[0]
            
        if newData[1] != "":
            employee.lastName = newData[1]
            
        if newData[2] != "":
            employee.job = newData[2]
            
        if newData[3] != "":
            employee.dept = newData[3]

        # add the changed employee back to the dictionary
        dictionary[ID] = employee

        # let the user know which employee has been updated
        if newData != ["","","",""]:
            print("\nEmployee", ID, "updated.\n")
        # if nothing changed, let the user know
        else:
            print("\nEmployee unchanged.\n")

    # if the ID isnt in dictionary, let the user know
    else:
        print("\nEmployee not Found\n")

    
## displays an employee's attributes to the user
#  @param dictionary the dictionary the employee is stored in
#  @param key the ID number of the employee
#
def showEmployee(dictionary, key):

    # get the employee object from dictionary
    employee = dictionary[key]
    
    # print each attribute
    print("\nEmployee ID number:", employee.IDnumber,
          "\nName:", employee.name,
          "\nJob Title:", employee.job,
          "\nDepartment:", employee.dept)
    
    
## uses a regex expression to check if the input is valid
#  @param ID the ID to be checked
#  @return True or False if the ID is all digits or not
#
def verifyID(ID):

    # regular expression to check for all digits
    regex = r"\d+"

    # input must match all digits
    if re.fullmatch(regex, ID) == None:
        return False
    
    else:
        return True

    
## creates a menu with options for changing each attribute of an employee
#  @param ID the ID of the employee to be changed
#  @return empList the list of new attributes to be given to the employee
#
def changeEmpMenu(ID):

    # define strings for the menu
    label = "\nChange one of the following for employee " + ID +":\n"
    options = """
    1. First name\n
    2. Last name\n
    3. Job title\n
    4. Department\n
    5. All Data\n
    6. Quit\n"""
    # output strings
    print(label, options)

    # get input from the user
    selection = input("Entry: ")

    # prompt for input depending on the selection
    if selection == "1":
        # get new first name input
        addFname = input("Enter the new first name of the employee: ")
        addLname = ""
        addJob = ""
        addDept = ""
    
    elif selection == "2":
        addFname = ""
        # get new last name input
        addLname = input("Enter the new last name of the employee: ")
        addJob = ""
        addDept = ""
        
    elif selection == "3":
        addFname = ""
        addLname = ""
        # get new job title input
        addJob = input("Enter the employee's new job title: ")
        addDept = ""
        
    elif selection == "4":
        addFname = ""
        addLname = ""
        addJob = ""
        # get new department input
        addDept = input("Enter the employee's new department: ")
        
    elif selection == "5":
        # get all new attributes or whichever ones the user wishes
        print("\nPress Enter without entering any data if you do not wish to change a certain piece of data.\n")
        addFname = input("Enter the first name of the employee: ")
        addLname = input("Enter the last name of the employee: ")
        addJob = input("Enter the employee's job title: ")
        addDept = input("Enter the employee's department: ")

    # if the user inputs something else, don't change anything about the employee data list
    else:
        addFname = ""
        addLname = ""
        addJob = ""
        addDept = ""
        
    # create a list of the data entered by the user
    # list contains empty space for attributes that are to remain unchanged
    empList = [addFname, addLname, addJob, addDept]
    
    return(empList)


## removes an employee from the dictionary
#  @param ID the ID number of the employee to be removed
#  @param dictionary the dictionary the employee is in
#
def deleteEmployee(ID, dictionary):
    
    # if the employee is in the dictionary, remove them
    if ID in dictionary:
        print("\nEmployee", ID, "Deleted\n")
        dictionary.pop(ID)

    # otherwise let the user know the employee is not in the dictionary
    else:
        print("\nEmployee not Found\n")
        

## updates the file storage with current dictionary data
#  @param file the file storage
#  @param dictionary the dictionary with data to be written
#
def updateFile(file, dictionary):

    # write the updated dictionary back to the file
    for key in dictionary:
        employee = dictionary[key]
        # write in comma seperated values format
        file.write(key + "," +
                   employee.firstName + "," +
                   employee.lastName + "," +
                   employee.dept + "," +
                   employee.job + "," + "\n")

                   
# run the program
main()

